from setuptools import find_packages
from setuptools import setup

# REQUIRED_PACKAGES = [
#     'gcsfs==0.7.1', 
#     'dask[dataframe]==2021.2.0', 
#     'google-cloud-bigquery-storage==2.0.0', 
#     'six==1.15.0',
#     'google-cloud==0.34.0',
#     'google-cloud-bigquery==3.5.0',
#     'google==3.0.0',
#     'google-cloud-core==2.5.0',
#     'google-cloud-storage==2.7.0',
#     'google-api-core==1.34.0',
#     'google-auth==1.25.0',
#     'db-dtypes==1.0.0',
#     'protobuf==3.20.3'
# ]

REQUIRED_PACKAGES = [
    'gcsfs==0.7.1', 
    'dask[dataframe]==2021.2.0', 
    'google-cloud-bigquery-storage==1.0.0', 
    'six==1.15.0',
    'google-auth-oauthlib==0.5.3',
    'google-api-core==1.23.0'
]

 
setup(
    name='trainer', 
    version='0.1', 
    install_requires=REQUIRED_PACKAGES,
    packages=find_packages(), # Automatically find packages within this directory or below.
    include_package_data=True, # if packages include any data files, those will be packed together.
    description='Classification training titanic survivors prediction model'
)